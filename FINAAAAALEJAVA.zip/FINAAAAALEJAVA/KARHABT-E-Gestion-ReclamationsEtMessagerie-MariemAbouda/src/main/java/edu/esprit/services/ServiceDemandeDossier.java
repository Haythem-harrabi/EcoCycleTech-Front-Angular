package edu.esprit.services;

import edu.esprit.entities.DossierDemande;
import edu.esprit.tools.DataSource;

import java.sql.*;
import java.util.HashSet;
import java.util.Set;
public class ServiceDemandeDossier implements IDemandeDossier<DossierDemande> {

    Connection cnx = DataSource.getInstance().getCnx();
    private int idu;


    @Override
    public void ajouter( DossierDemande dossierDemande) {
        String req = "INSERT INTO demande_dossier (idu, urlcin, urlcerretenu, urlatttravail, urldecrevenu, urlextnaissance) VALUES (?,?,?,?,?,?)";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);

            ps.setInt(1, idu);  // Set the user ID
            ps.setString(2, dossierDemande.getUrlcin());
            ps.setString(3, dossierDemande.getUrlCerRetenu());
            ps.setString(4, dossierDemande.getUrlAttTravail());
            ps.setString(5, dossierDemande.getUrlDecRevenu());
            ps.setString(6, dossierDemande.getUrlExtNaissance());

            ps.executeUpdate();

            // Vérification des valeurs saisies
            if (dossierDemande.getUrlcin() == null || dossierDemande.getUrlcin().isEmpty()) {
                throw new IllegalArgumentException("L'URL du CIN ne peut pas être vide.");
            }
            if (dossierDemande.getUrlCerRetenu() == null || dossierDemande.getUrlCerRetenu().isEmpty()) {
                throw new IllegalArgumentException("L'URL du certificat de retenue ne peut pas être vide.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void ajouter(int userId, DossierDemande dossierDemande) {

    }


    @Override
    public void modifier(int idu, DossierDemande dossierDemande) {

        String req = "UPDATE demande_dossier SET urlcin= ?, urlcerretenu = ?, urlatttravail= ?, urldecrevenu = ? , urlextnaissance= ?  WHERE id_demande = ?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setString(1, dossierDemande.getUrlcin());
            ps.setString(2, dossierDemande.getUrlCerRetenu());
            ps.setString(3, dossierDemande.getUrlAttTravail());
            ps.setString(4, dossierDemande.getUrlDecRevenu());
            ps.setString(5, dossierDemande.getUrlExtNaissance());
            ps.setInt(6, idu);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Dossier with ID " + idu + " modified successfully!");
            } else {
                System.out.println("No dossier found with ID " + idu);
            }
        } catch (SQLException e) {
            System.out.println("Error modifying dossier: " + e.getMessage());
        }
    }


    @Override
    public void supprimerid(int idu) {
        try {
            String requete = "DELETE FROM demande_dossier WHERE idu =?";
            System.out.println("demande supprimé");
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(1, idu);
            pst.executeUpdate();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void supprimer(DossierDemande dossierDemande) {
        try {
            String requete = "DELETE FROM demande_dossier WHERE idu =?";
            System.out.println("demande supprimé");
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(1, dossierDemande.getId_demande());
            pst.executeUpdate();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }


    @Override
    public DossierDemande getOneById(int id_demande) {
        String req = "SELECT * FROM demande_dossier WHERE id_demande = ?";
        try {
            PreparedStatement ps = cnx.prepareStatement(req);
            ps.setInt(1, id_demande);

            ResultSet resultSet = ps.executeQuery();
            if (resultSet.next()) {
                // Create a Dossier object from the retrieved data
                DossierDemande dd = new DossierDemande();
                dd.setId_demande(resultSet.getInt("id_demande"));
                dd.setUrlcin(resultSet.getString("urlcin"));
                dd.setUrlCerRetenu(resultSet.getString("urlCerRetenu"));
                dd.setUrlAttTravail(resultSet.getString("AttTravail"));
                dd.setUrlDecRevenu(resultSet.getString("DecRevenu"));
                dd.setUrlExtNaissance(resultSet.getString("ExtNaissance"));

                return dd;
            } else {
                System.out.println("No dossier found with ID " + id_demande);
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving dossier: " + e.getMessage());
            return null;
        }
    }

    @Override
    public Set<DossierDemande> getAll() {
        Set<DossierDemande> demandeSet = new HashSet<>();
        String requete = "SELECT * FROM demandedossier";
        try {
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                DossierDemande d = new DossierDemande();
                d.setId_demande(rs.getInt("id_demande"));
                d.setUrlcin(rs.getString("urlcin"));
                d.setUrlCerRetenu(rs.getString("urlCerRetenu"));
                d.setUrlAttTravail(rs.getString("AttTravail"));
                d.setUrlDecRevenu(rs.getString("DecRevenu"));
                d.setUrlExtNaissance(rs.getString("ExtNaissance"));

                demandeSet.add(d);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return demandeSet;

    }

    public void setText(String string) {
    }
}
