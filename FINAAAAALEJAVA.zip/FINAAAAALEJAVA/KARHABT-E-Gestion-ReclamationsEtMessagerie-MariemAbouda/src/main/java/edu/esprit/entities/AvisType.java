package edu.esprit.entities;

public enum AvisType {
   POSITIVE,
    NEGATIVE,
    NEUTRE
}
