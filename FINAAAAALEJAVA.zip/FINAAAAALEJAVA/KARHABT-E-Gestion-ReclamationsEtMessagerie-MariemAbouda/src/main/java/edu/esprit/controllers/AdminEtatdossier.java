package edu.esprit.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

public class AdminEtatdossier {

    @FXML
    private Button but_demande;

    @FXML
    private Button but_etat;

    @FXML
    private Button butt_dos;

    @FXML
    private ComboBox<?> combo;

    @FXML
    private Pane dossier_table1;

    @FXML
    private TableColumn<?, ?> etat_col;

    @FXML
    private TableView<?> etat_table;

    @FXML
    private TableColumn<?, ?> idEtat_col;

    @FXML
    private Pane most_inner_pane;

    @FXML
    private HBox root;

    @FXML
    private TextField searchField;

    @FXML
    private Button tfdelete;

    @FXML
    private Pane tfinnerPane;

    @FXML
    private Button tfmodify;

    @FXML
    private Button tfshowetat;

    @FXML
    private AnchorPane tfsideBar;

    @FXML
    private Button tfvalider;

    @FXML
    void ModifierEtatDossier(ActionEvent event) {

    }

    @FXML
    void SaveEtatDossier(ActionEvent event) {

    }

    @FXML
    void SupprimerEtatDossier(ActionEvent event) {

    }

    @FXML
    void bttdossier(ActionEvent event) {

    }

    @FXML
    void dashdossier(ActionEvent event) {

    }

    @FXML
    void demandedoss(ActionEvent event) {

    }

    @FXML
    void displayDetailsInTextField(MouseEvent event) {

    }

    @FXML
    void showEtatdossier(ActionEvent event) {

    }

}
