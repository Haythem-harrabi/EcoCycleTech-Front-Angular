package edu.esprit.entities;
import java.time.LocalDate;
import java.sql.Date;
import java.util.Objects;
public class Dossier {

    private int cin;
    private String nom;
    private String prenom ;
    private String region ;
    private Date date ;

    private int montant;
    private int id;

    private int demande_dossier_id;


    public Dossier(int cin, String nom, String prenom , String region , Date date , int montant) {
        this.cin = cin;
        this.nom = nom;
        this.prenom = prenom;
        this.region=region;
        this.date=date;
        this.montant=montant;
    }

    public Dossier(int id,int cin, String nom, String prenom, String region, Date date, int montant) {

        this.id = id;
        this.cin = cin;
        this.nom = nom;
        this.prenom = prenom;
        this.region = region;
        this.date = date;
        this.montant = montant;
    }

    public Dossier() {
    }

    public int getCin() {
        return cin;
    }
    public int getMontant() {
        return montant;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getRegion() {
        return region;
    }

    public Date getDate() {
        return date;
    }
    public int getDemande_dossier_id() {
        return demande_dossier_id;
    }

    public int getId() {
        return id;
    }

    public void setCin(int cin) {
        this.cin = cin;
    }
    public void setMontant(int montant) {
        this.montant = montant;
    }
     public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    public void setDemande_dossier_id(int demande_dossier_id) {
        this.demande_dossier_id = demande_dossier_id;
    }
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Dossier{" +
                "cin=" + cin +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", region='" + region + '\'' +

                ", date='" + date + '\'' +
                ", montant=" + montant +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dossier dossier = (Dossier) o;

        return id == dossier.id;
    }
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }


}
